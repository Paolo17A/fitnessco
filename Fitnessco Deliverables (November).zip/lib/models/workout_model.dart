class Workout {
  String? muscle;
  String? workout;
  int? sets;
  int? reps;

  Workout(
      {required this.muscle,
      required this.workout,
      required this.sets,
      required this.reps});
}
